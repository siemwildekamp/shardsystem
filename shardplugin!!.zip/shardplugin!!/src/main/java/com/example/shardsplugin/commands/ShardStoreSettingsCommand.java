package com.example.shardsplugin;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ShardStoreSettingsCommand implements CommandExecutor {
    private final ShardsPlugin plugin;

    public ShardStoreSettingsCommand(ShardsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cThis command can only be used by players!");
            return true;
        }

        if (!sender.hasPermission("shardsplugin.canchangestore")) {
            sender.sendMessage("§cYou don't have permission to use this command!");
            return true;
        }

        if (args.length != 2) {
            sender.sendMessage("§cUsage: /shardstoresettings <item> <price>");
            return true;
        }

        try {
            Material material = Material.valueOf(args[0].toUpperCase());
            int price = Integer.parseInt(args[1]);

            if (price < 0) {
                sender.sendMessage("§cPrice cannot be negative!");
                return true;
            }

            plugin.getShardStore().setPrice(material, price);
            sender.sendMessage("§aSuccessfully set the price of " + material.name() + " to " + price + " shards!");
        } catch (IllegalArgumentException e) {
            sender.sendMessage("§cInvalid item name or price!");
        }

        return true;
    }
}