package com.example.shardsplugin;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HoeveelShardsCommand implements CommandExecutor {
    private final ShardsPlugin plugin;

    public HoeveelShardsCommand(ShardsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cThis command can only be used by players!");
            return true;
        }

        Player player = (Player) sender;
        int shards = plugin.getShardManager().getShards(player.getUniqueId());
        player.sendMessage("§6You have §e" + shards + " §6shards!");
        return true;
    }
}