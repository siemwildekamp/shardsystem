package com.example.shardsplugin;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ShardStore {
    private final ShardsPlugin plugin;
    private final Map<Material, Integer> prices;
    private final File storeFile;
    private FileConfiguration storeConfig;

    public ShardStore(ShardsPlugin plugin) {
        this.plugin = plugin;
        this.prices = new HashMap<>();
        this.storeFile = new File(plugin.getDataFolder(), "store.yml");
        loadData();
        setupDefaultItems();
    }

    private void setupDefaultItems() {
        if (prices.isEmpty()) {
            // Diamond Armor
            prices.put(Material.DIAMOND_HELMET, 50);
            prices.put(Material.DIAMOND_CHESTPLATE, 80);
            prices.put(Material.DIAMOND_LEGGINGS, 70);
            prices.put(Material.DIAMOND_BOOTS, 40);
            
            // Diamond Tools
            prices.put(Material.DIAMOND_SWORD, 40);
            prices.put(Material.DIAMOND_PICKAXE, 40);
            prices.put(Material.DIAMOND_AXE, 40);
            prices.put(Material.DIAMOND_SHOVEL, 20);
            
            // Food
            prices.put(Material.GOLDEN_APPLE, 15);
            prices.put(Material.COOKED_BEEF, 5);
            saveData();
        }
    }

    public void loadData() {
        if (!storeFile.exists()) {
            plugin.saveResource("store.yml", false);
        }
        storeConfig = YamlConfiguration.loadConfiguration(storeFile);
        
        for (String materialName : storeConfig.getKeys(false)) {
            Material material = Material.valueOf(materialName);
            prices.put(material, storeConfig.getInt(materialName));
        }
    }

    public void saveData() {
        try {
            for (Map.Entry<Material, Integer> entry : prices.entrySet()) {
                storeConfig.set(entry.getKey().name(), entry.getValue());
            }
            storeConfig.save(storeFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save store data!");
        }
    }

    public void openStore(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, "§6Shard Shop");
        
        for (Map.Entry<Material, Integer> entry : prices.entrySet()) {
            ItemStack item = new ItemStack(entry.getKey());
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName("§e" + entry.getKey().name());
            meta.setLore(java.util.Arrays.asList(
                "§7Price: §6" + entry.getValue() + " shards",
                "§7Click to purchase!"
            ));
            item.setItemMeta(meta);
            inv.addItem(item);
        }
        
        player.openInventory(inv);
    }

    public void setPrice(Material material, int price) {
        prices.put(material, price);
        saveData();
    }

    public int getPrice(Material material) {
        return prices.getOrDefault(material, 0);
    }

    public boolean purchaseItem(Player player, Material material) {
        int price = getPrice(material);
        if (price <= 0) return false;

        ShardManager shardManager = plugin.getShardManager();
        if (!shardManager.hasEnoughShards(player.getUniqueId(), price)) {
            player.sendMessage("§cYou don't have enough shards!");
            return false;
        }

        shardManager.removeShards(player.getUniqueId(), price);
        player.getInventory().addItem(new ItemStack(material));
        player.sendMessage("§aSuccessfully purchased " + material.name() + " for " + price + " shards!");
        return true;
    }
}