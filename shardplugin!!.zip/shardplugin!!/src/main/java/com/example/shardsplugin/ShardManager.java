package com.example.shardsplugin;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ShardManager {
    private final ShardsPlugin plugin;
    private final Map<UUID, Integer> playerShards;
    private final File shardsFile;
    private FileConfiguration shardsConfig;

    public ShardManager(ShardsPlugin plugin) {
        this.plugin = plugin;
        this.playerShards = new HashMap<>();
        this.shardsFile = new File(plugin.getDataFolder(), "shards.yml");
        loadData();
    }

    public void loadData() {
        if (!shardsFile.exists()) {
            plugin.saveResource("shards.yml", false);
        }
        shardsConfig = YamlConfiguration.loadConfiguration(shardsFile);
        
        for (String uuidStr : shardsConfig.getKeys(false)) {
            playerShards.put(UUID.fromString(uuidStr), shardsConfig.getInt(uuidStr));
        }
    }

    public void saveData() {
        try {
            for (Map.Entry<UUID, Integer> entry : playerShards.entrySet()) {
                shardsConfig.set(entry.getKey().toString(), entry.getValue());
            }
            shardsConfig.save(shardsFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save shards data!");
        }
    }

    public int getShards(UUID playerUUID) {
        return playerShards.getOrDefault(playerUUID, 0);
    }

    public void addShard(UUID playerUUID) {
        int currentShards = getShards(playerUUID);
        playerShards.put(playerUUID, currentShards + 1);
    }

    public void removeShards(UUID playerUUID, int amount) {
        int currentShards = getShards(playerUUID);
        playerShards.put(playerUUID, Math.max(0, currentShards - amount));
    }

    public boolean hasEnoughShards(UUID playerUUID, int amount) {
        return getShards(playerUUID) >= amount;
    }
}