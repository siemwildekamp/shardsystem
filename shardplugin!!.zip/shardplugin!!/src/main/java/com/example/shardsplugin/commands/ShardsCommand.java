package com.example.shardsplugin;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class ShardsCommand implements CommandExecutor {
    private final ShardsPlugin plugin;

    public ShardsCommand(ShardsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cThis command can only be used by players!");
            return true;
        }

        Player player = (Player) sender;
        if (plugin.getShardLocation() == null) {
            player.sendMessage("§cThe shard location has not been set yet!");
            return true;
        }

        player.teleport(plugin.getShardLocation());
        startTimer(player);
        return true;
    }

    private void startTimer(Player player) {
        new BukkitRunnable() {
            int secondsLeft = 60;

            @Override
            public void run() {
                if (!player.isOnline() || secondsLeft <= 0) {
                    this.cancel();
                    return;
                }

                player.spigot().sendMessage(
                    ChatMessageType.ACTION_BAR,
                    new TextComponent("§6Next shard in: §e" + secondsLeft)
                );

                secondsLeft--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }
}