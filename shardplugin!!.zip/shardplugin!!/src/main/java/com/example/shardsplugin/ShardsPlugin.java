package com.example.shardsplugin;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class ShardsPlugin extends JavaPlugin {
    private Location shardLocation;
    private ShardManager shardManager;
    private ShardStore shardStore;

    @Override
    public void onEnable() {
        // Save default config
        saveDefaultConfig();
        
        // Initialize managers
        this.shardManager = new ShardManager(this);
        this.shardStore = new ShardStore(this);
        
        // Register commands
        getCommand("shards").setExecutor(new ShardsCommand(this));
        getCommand("hoeveelshards").setExecutor(new HoeveelShardsCommand(this));
        getCommand("shardstore").setExecutor(new ShardStoreCommand(this));
        getCommand("shardstoresettings").setExecutor(new ShardStoreSettingsCommand(this));
        getCommand("setshard").setExecutor(new SetShardCommand(this));
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new ShardListener(this), this);
        
        // Start shard timer
        startShardTimer();
        
        // Load shard location from config
        loadShardLocation();
    }

    @Override
    public void onDisable() {
        // Save all data
        saveShardLocation();
        shardManager.saveData();
        shardStore.saveData();
    }

    private void startShardTimer() {
        new BukkitRunnable() {
            @Override
            public void run() {
                Bukkit.getOnlinePlayers().forEach(player -> {
                    if (isAtShardLocation(player.getLocation())) {
                        shardManager.addShard(player.getUniqueId());
                    }
                });
            }
        }.runTaskTimer(this, 1200L, 1200L); // Run every minute (20 ticks * 60)
    }

    private boolean isAtShardLocation(Location playerLoc) {
        if (shardLocation == null) return false;
        return playerLoc.getWorld().equals(shardLocation.getWorld()) &&
               playerLoc.distance(shardLocation) <= 10;
    }

    private void loadShardLocation() {
        FileConfiguration config = getConfig();
        if (config.contains("shardLocation")) {
            this.shardLocation = (Location) config.get("shardLocation");
        }
    }

    private void saveShardLocation() {
        FileConfiguration config = getConfig();
        if (shardLocation != null) {
            config.set("shardLocation", shardLocation);
            saveConfig();
        }
    }

    public Location getShardLocation() {
        return shardLocation;
    }

    public void setShardLocation(Location location) {
        this.shardLocation = location;
        saveShardLocation();
    }

    public ShardManager getShardManager() {
        return shardManager;
    }

    public ShardStore getShardStore() {
        return shardStore;
    }
}